# -*- coding: utf-8 -*-

import pickle
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import DotProduct, WhiteKernel
import numpy as np
import matplotlib.pyplot as plt
from sklearn import metrics
from mpl_toolkits.mplot3d import Axes3D  # 实现数据可视化3D
import math
from sklearn.gaussian_process.kernels import RBF, ConstantKernel as C

def draw_3D_alloy_CL_model(alloy_no, data, x_min, x_max, x_ind, x_data, y_min, y_max, y_ind, y_data, CL_data, reg, p_title, x_label, y_label):
    # 创建一个作图用的网格的测试数据
    x_inte = (x_max - x_min) / 20.0
    y_inte = (y_max - y_min) / 20.0
    xset, yset = np.meshgrid(np.arange(x_min, x_max, x_inte), np.arange(y_min, y_max, y_inte))

    # 制作其他成分为固定值的数据 只有x, y两维成分是meshgrid，其他都是固定值
    pred_data = []
    mesh = np.c_[xset.ravel(), yset.ravel()]
    for i in range(len(mesh)):
        pred_data.append([])
        for j in range(len(data[alloy_no]) - 1):
            pred_data[i].append(data[alloy_no][j])
        pred_data[i][x_ind] = mesh[i][0]
        pred_data[i][y_ind] = mesh[i][1]
    pred_data = np.array(pred_data)

    # 查看网格测试数据输出结果，并返回标准差。
    output, err = reg.predict(pred_data, return_std=True)
    output, err = output.reshape(xset.shape), err.reshape(xset.shape)  # 使均值和方差的维数与xset一致
    sigma = np.sum(reg.predict(data[:, :-1], return_std=True)[1])  # 预测原来的给出的data在z上的数据，[1]返回方差
    up, down = output * (1 + 1.96 * err), output * (1 - 1.96 * err)  # 这是置信区间95%

    fig = plt.figure(figsize=(10.5, 5))
    ax1 = fig.add_subplot(121, projection='3d')
    if 0:  # 如果预测CL取了log，画图结果还原
        output = np.power(10, output)
    surf = ax1.plot_wireframe(xset, yset, output, antialiased=True)
    ax1.scatter(x_data[alloy_no], y_data[alloy_no], CL_data[alloy_no], c='red')  # 只画出alloy_no的点
    ax1.set_title(p_title)
    ax1.set_xlabel(x_label)
    ax1.set_ylabel(y_label)
    ax1.set_zlabel('logCL')
    # ax1.set_zlabel('CL')
    plt.savefig(f"result/Alloy-CL-model-plot-gaussian-process/Alloy-cl-GPR-{x_label}-{y_label}-{alloy_no}.jpg", dpi=300)
    # plt.show()
    # exit()

if __name__ == "__main__":
    # 把高斯过程回归得到的所有合金在 TT= 800 S = 300下的的CL读进来
    fp = open(f"result/current-data/CL-TT-S-dataset-Gaussian-regression-800-300.pkl", "rb")
    result_800_300 = pickle.load(fp)
    fp.close()
    print("合金蠕变寿命数据读取完毕！")


    if 1:  # 结果中有负数，负数都变成0，CL 不可能是负数，但是预测特别小，也说明这个点的CL就是很小。
        for key in result_800_300:
            if result_800_300[key][0] < 0:
                result_800_300[key][0] = 0.000001
    if 0:  # 为了让预测曲面都>0，结果取log
        for key in result_800_300:
            result_800_300[key][0] = math.log10(result_800_300[key][0])


    # 把所有合金成分读进来
    # [Co, Mo, Cr, W, Al, Ti, Nb, Ta, C, B, Zr, Hf, Fe, V]
    fp = open(f"result/alloy-element.pkl", "rb")
    alloy_element = pickle.load(fp)
    fp.close()
    print("合金成分数据读取完毕！")

    if 0:  # 计算合金总成分含量at%
        print([np.sum(alloy_element[key]) for key in alloy_element])
        exit()

    # 高斯过程回归 建立 合金成分-CL模型
    data = []
    for key in alloy_element:
        l = alloy_element[key] + [result_800_300[key][0]]
        data.append(l)
    data = np.array(data)

    if 1:  # JMatPro预测的合金成分和蠕变结果 合金成分顺序  Co Mo Cr W Al Ti Nb Ta C B Zr Hf Fe V Ni
        comp = [[9.86, 1.09, 10.05,3.16,12.06,3.03,0.63,0,0.82,0,0,0,0,0],[10.95,4.89,21.43,0.96,3.48,4.04,0,0,0.24,0,0,0,0,0],[18.37,0,24.65,0.62,2.53,2.68,0.49,0.31,0.71,0.05,0.01,0,0,0],[10.79,6.03,21.13,0,3.43,3.87,0,0,0.43,0.03,0,0,0,0],[10.92,1.2,17.67,1.72,5.96,5.52,0.12,0,0.43,0.11,0.03,0,0,0],[0,6.25,21.93,1.47,2.78,3.13,0,0,0.35,0,0,0,0,0],[10.52,0.35,22.76,1.07,5.22,4.12,0.15,0,0.47,0.08,0.02,0,0,0],[0,1.82,36.87,1.58,2.15,1.21,0.63,0,0.39,0,0,0,0,0],[0,0,20.45,0,2.9,2.69,0,0,0.33,0,0,0,0,0],[10.05,0,10.26,3.22,12.08,1.86,0,0.82,0.74,0.08,0.03,0.5,0,0],[0,2.96,20.75,0,2.74,3.32,0,0,0.28,0,0,0,9.15,0],[0,6.04,20.12,0,7.55,2.95,0,0,0.28,0.39,0,0,0,0],[9.23,1.7,9.41,0,10.58,5,0,0,0.77,0.09,0.04,0,0,0.8],[10.69,1.13,17.39,1.65,6.37,5.5,0.12,0,0.29,0.42,0,0.1,0,0],[0,2.13,17.93,1.59,3.89,2.92,0.69,0,0.49,0,0,0,15.65,0],[0,0,22.81,0,1.88,3.19,0.85,0,0.05,0,0,0,0,0],[9.58,2.29,10.85,1.47,11.3,2.89,0,0,0.66,0.1,0.04,0,0,0],[13.84,1.7,9.41,0,10.48,5.4,0,0,0.77,0.09,0.04,0,0,0.8],[0,2.47,13.26,0,12.26,0.86,1.31,0,0.06,0.07,0.06,0,0,0],[12.01,1.23,6.8,3.21,11.91,1.54,1.84,0,0.59,0.41,0.04,0,0,0],[12.11,1.24,6.86,3.27,12.02,1.55,1.6,0,0.57,0.41,0.04,0.47,0,0],[4.77,1.76,9.73,1.07,12.51,0,1.27,0,0.47,0.1,0,0,0,0],[9.65,3.56,8.75,0,12.65,1.19,0,1.32,0.05,0.08,0.05,0,0,0],[12.58,1.72,10.04,0.42,10.79,5.16,0.44,0,0.78,0.08,0.03,0,0,0.81],[8.11,1,17.08,0.8,8.34,4.23,0.42,0.53,0.8,0.05,0,0,0,0],[9.28,0.9,17.15,1.57,6.4,4.21,1.24,0,0.48,0.08,0.03,0,0,0],[0,0,22.17,0,1.67,3.05,0,0,0.23,0,0,0,0,0],[0,1.84,16.42,1.92,4.36,2.46,0,0,0.29,0,0,0,0,0.35],[14.8,3.03,11.18,1.74,8.62,1.94,0,0,0.34,0,0,0,0,0.46],[17.06,0,20.41,0,3.1,2.92,0,0,0.47,0,0,0,0,0],[14.38,3.65,11.24,1.91,9.1,3.05,0,0,0.05,0,0,0,0,0.57],[0,2.01,16.3,1.91,5.63,2.44,0,0,0.34,0,0,0,0,0.69],[16.56,2.33,20.38,0,6.2,3.5,0,0,0.23,0,0,0,0,0],[14.32,1.76,19.47,0.46,5.21,5.88,0.01,0,0.23,0,0,0,0,0],[4.98,2.47,11.93,1.6,11.71,3.06,0,0,0.7,0.09,0.03,0,0,0],[0,3.01,16.56,0,7.41,2.9,0,0,0.69,0.39,0.04,0,0,0],[0,2.29,18.05,1.76,4.13,2.39,0,0,0.63,0.04,0,0,0,0],[0,2.59,12.72,0,12.26,0.81,1.19,0,0.23,0.05,0.06,0,0,0],[9.07,4.87,11.36,0,8.65,4.23,0,0,0.7,0,0,0,0,0],[8.18,1.03,17.44,0.8,7.35,3.85,0.49,0.55,0.71,0.05,0.06,0,0,0],[0,1.43,18.75,4.48,8.02,0,0,0,0.15,0.03,0,0,0,0],[6.46,2.57,20.85,1.98,5.87,1.47,0,0,0.24,0,0,0,0,0],[0,3.09,21.64,2.09,4.61,1.48,0,0,0.35,0,0,0,0,0],[17.04,0,21.45,0,3.1,2.91,0,0,0.46,0,0,0,0,0],[13.03,2.55,20.23,0,2.95,3.56,0,0,0.28,0,0,0,0,0]]
        # 800 °C 300 MPa
        # rupture = [5213.03, 1116.39, 147.432, 732.617, 4320.25, 144.211, 2886.37, 35.6252, 12.2685, 3915.21, 125.805, 1451.53, 2070.73, 4644.46, 254.145, 22.0334, 2994.57, 3202.71, 1402.91, 3171.27, 3769.22, 1409.73, 2525.04, 3636.32, 3548.03, 3305.67, 6.14177, 74.4958, 1725.12, 75.5919, 2949.05, 266.594, 2758.32, 4921.4, 3199.79, 1000.3, 67.4893, 1371.37, 2285.23, 2657.16, 136.815, 92.2272, 43.3412, 91.6287, 210.407]
        # 950 °C 300 MPa
        rupture = [79.4462, 3.69342, 0.282452, 2.62067, 64.3027, 0.325735, 10.1001, 0.0298043, 0.00249688, 60.2372, 0.191797, 3.14845, 37.7885, 66.4591, 0.485562, 0.00126731, 50.8121, 49.1327, 22.4204, 56.8314, 68.3206, 25.3765, 37.0727, 57.395, 47.9448, 46.3583, 0.00301142, 0.0957946, 2.53228, 0.0458453, 44.473, 0.596179, 5.0681, 64.3106, 55.9809, 3.40358, 0.0707145, 22.6063, 38.7747, 36.7093, 0.179915, 0.247842, 0.0231939, 0.0826049, 0.546064]
        data = [comp[i]+[rupture[i]] for i in range(len(comp))]
        data = np.array(data)

    # 核函数的取值
    # kernel = C(0.1, (0.001, 0.1)) * RBF(0.5, (1e-4, 10))
    # kernel = 1000 * RBF(100, (1e-5, 1))  # RBF length_scale length_scale_bounds
    # kernel = 0.33 ** 2 * DotProduct(sigma_0=1.04) ** 2 + WhiteKernel()
    # kernel = DotProduct(sigma_0=100) ** 3 + WhiteKernel()  # 点乘内核 平面 无偏角度
    kernel = DotProduct(sigma_0=100) ** 2  # 点乘内核 有偏角度平面

    # 创建高斯过程回归,并训练
    reg = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=10, alpha=0.1)
    reg.fit(data[:, :-1], data[:, -1])  # 这是拟合高斯过程回归的步骤，data[:,:-1]获取前n列元素值，data[:,-1]获取最后一列元素的值

    pred, pred_err = reg.predict(data[:, :-1], return_std=True)
    true = data[:, -1]
    MAE = round(metrics.mean_absolute_error(pred, true), 2)
    RMSE = round(np.sqrt(metrics.mean_squared_error(pred, true)), 2)
    print("MAE = ", MAE)
    print("RMSE = ", RMSE)
    exit()

    if 1:  # 存储高斯过程训练得到的合金-CL模型
        fp = open(f"result/Alloy-CL-model-Gaussian-process-reg.pkl", "wb")
        pickle.dump(reg, fp, -1)
        fp.close()
        print("保存完毕")
        exit()

    if 0:  # 计算单点的CR预测值
        pred, pred_err = reg.predict(np.array([[0, 2.73, 36.87, 0, 12.65, 0, 0, 0, 0.82, 0, 0.06, 0, 15.65, 0]]), return_std=True)
        print("pred = ", pred)
        exit()

    # 计算已知点预测误差
    pred, pred_err = reg.predict(data[:, :-1], return_std=True)
    true = data[:, -1]

    MAE = round(metrics.mean_absolute_error(pred, true), 2)
    RMSE = round(np.sqrt(metrics.mean_squared_error(pred, true)), 2)

    print("MAE = ", MAE)
    print("RMSE = ", RMSE)
    exit()

    """
    可视化
    思路是找出常用的影响CL的几种主要成分，两两配合画图 成分1-成分2-CL，看趋势是否准确
    除了这两维，其他成分都得是固定值，主要是看看是否出现离散点，是否拟合比较连续
     
    [Co, Mo, Cr, W, Al, Ti, Nb, Ta, C, B, Zr, Hf, Fe, V]
    与CL关系大的合金（材料经验）：Co, Mo, Cr, W, Al, Ti, Nb, Ta
    主成分分析占比大元素：Co, Cr, W, Al
    其中Mo和W越高越好，但两者总和必须小于某个范围  
    匹配：Mo-W; Co-Cr; Co-Al; Cr-Al
    """
    if 1:
        # 计算合金成分中的最大值和最小值，确定可视化范围
        Co_min, Co_max, Co_data, Co_ind = data[:, 0].min(), data[:, 0].max(), data[:, 0], 0
        Mo_min, Mo_max, Mo_data, Mo_ind = data[:, 1].min(), data[:, 1].max(), data[:, 1], 1
        Cr_min, Cr_max, Cr_data, Cr_ind = data[:, 2].min(), data[:, 2].max(), data[:, 2], 2
        W_min, W_max, W_data, W_ind = data[:, 3].min(), data[:, 3].max(), data[:, 3], 3
        Al_min, Al_max, Al_data, Al_ind = data[:, 4].min(), data[:, 4].max(), data[:, 4], 4
        CL_data = data[:, -1]

        # for i in [0]:  # 选择哪个合金其余成分为固定值
        alloy_num = len(alloy_element)
        for alloy_no in range(alloy_num):  # 判断每个合金周围都是连续的
            # Mo-W-CL
            draw_3D_alloy_CL_model(alloy_no, data, Mo_min, Mo_max, Mo_ind, Mo_data, W_min, W_max, W_ind, W_data, CL_data, reg, "MO-W-CL-Gaussian process", "Mo", "W")
            # Co-Cr-CL
            draw_3D_alloy_CL_model(alloy_no, data, Co_min, Co_max, Co_ind, Co_data, Cr_min, Cr_max, Cr_ind, Cr_data, CL_data, reg, "Co-Cr-CL-Gaussian process", "Co", "Cr")
            # Co-Al-CL
            draw_3D_alloy_CL_model(alloy_no, data, Co_min, Co_max, Co_ind, Co_data, Al_min, Al_max, Al_ind, Al_data, CL_data, reg, "Co-Cr-CL-Gaussian process", "Co", "Al")
            # Cr-Al-CL
            draw_3D_alloy_CL_model(alloy_no, data, Cr_min, Cr_max, Cr_ind, Cr_data, Al_min, Al_max, Al_ind, Al_data, CL_data, reg, "Cr-Cr-CL-Gaussian process", "Cr", "Al")

        a = 1

