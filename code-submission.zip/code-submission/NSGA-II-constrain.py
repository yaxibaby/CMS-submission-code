# -*- coding: utf-8 -*-
import geatpy as ea
import pickle
import numpy as np
import sys
"""
"""

def at2wt(metals):
    # 输入合金成分
    metal_content_name = ['Co', 'Mo', 'Cr', 'W', 'Al', 'Ti', 'Nb', 'Ta', 'C', 'B', 'Zr', 'Hf', 'Fe', 'V']
    molemass = {'Cr': 51.9961, 'Co': 58.933195, 'Mo': 95.94, 'W': 183.84, 'Ta': 180.94788, 'Re': 186.207, 'Hf': 178.49, 'Al': 26.981539,
                'Ti': 47.867, 'Ru': 101.07, 'Nb': 92.90638, 'V': 50.9415, 'Ni': 58.6934, 'C':12.011,'Fe':55.845,'B':10.811,'Zr':91.224}
    # molemass = {'Cr': 52, 'Co': 58.93, 'Mo': 95.94, 'W': 183.8, 'Ta': 180.9, 'Re': 186.2, 'Hf': 178.5, 'Al': 26.98,
    #             'Ti': 47.87, 'Ru': 101.1, 'Nb': 92.91, 'V': 50.942, 'Ni': 58.69, 'C': 12.011, 'Fe': 55.845, 'B': 10.811,
    #             'Zr': 91.224}
    item_weights = []
    for index in range(len(metals)):
        item_weights.append(molemass[metal_content_name[index]]*metals[index])
    item_weights.append((100-sum(metals))*molemass['Ni'])
    total_weight = sum(item_weights)
    wt_items = []
    for index in range(len(metals)):
        wt_items.append(round(item_weights[index]/total_weight*100,3))
    return wt_items


class MyProblem(ea.Problem):  # 继承Problem父类

    def __init__(self, lb, ub, reg):
        M = 2
        name = 'MyProblem'  # 初始化name（函数名称，可以随意设置）
        Dim = 14  # 初始化Dim（决策变量维数）
        maxormins = [-1, 1]  # 初始化maxormins（目标最小最大化标记列表，1：最小化该目标；-1：最大化该目标）
        varTypes = [0] * Dim  # 初始化varTypes（决策变量的类型，0：实数；1：整数）
        lb = lb  # 决策变量下界
        ub = ub  # 决策变量上界

        # 调用父类构造方法完成实例化
        ea.Problem.__init__(self, name, M, maxormins, Dim, varTypes, lb, ub)

        self.reg = reg

    def cal_cost(self, vars):
        # 合金顺序 Co Mo Cr W Al Ti Nb Ta C B Zr Hf Fe V Ni
        # cost_list = [1,2,3,4,5,6,7,8,9,10,11,12,13,14]  # TODO
        cost_list = [335, 348.5, 72.75, 117, 18.11, 80, 610, 3600, 0.82, 8.55, 205, 23308, 16.23, 1900]
        other_alloy_cost = np.sum([vars[i] * cost_list[i] for i in range(len(vars))])
        Ni_cost = (100 - np.sum(vars)) * 175.8  # Ni价格175.8
        if 1:  # 约束1: mdi*var之和必须小于0.98，才能保证gamma+gamma'>99%
            mdi = [0.777, 1.55, 1.142, 1.655, 1.9, 2.271, 2.117, 2.224, 0, 0, 2.944, 3.02, 0.858, 1.543]
            md = np.sum([vars[i] * mdi[i] for i in range(len(vars))])
            md = md + (100 - np.sum(vars)) * 0.717  # Ni的Mdi
            mdi_thre = 98
            if md - mdi_thre <= 0:
                constraint_term_1 = 0
            else:
                constraint_term_1 = 1000000000000 * (md - mdi_thre)
        if 1:  # 约束2:  Ni > 55%
            Ni_comp = 100 - np.sum(vars)
            if Ni_comp > 55:
                constraint_term_2 = 0
            else:
                constraint_term_2 = 1000000000000
        if 1:  # 约束3:  W:3 + Mo:1 < 6%
            a = 1
            if vars[3] + vars[1] < 6:
                constraint_term_3 = 0
            else:
                constraint_term_3 = 1000000000000
        if 1:  # 约束4: Cr:2 + W:3 + Mo:1 <= 30%
            if vars[2] + vars[3] + vars[1] <= 30:
                constraint_term_4 = 0
            else:
                constraint_term_4 = 1000000000000
        if 0:  # 约束4: solvus temperature < 1170
            # 合金顺序 Co Mo Cr W Al Ti Nb Ta C B Zr Hf Fe V Ni
            wt_vars = at2wt(vars)
            Co_wt, Cr_wt, Mo_wt, W_wt, Re_wt, Ru_wt, Al_wt, Ti_wt, Ta_wt = wt_vars[0], wt_vars[2], wt_vars[1], wt_vars[3], 0, 0, wt_vars[4],  wt_vars[5], 0
            solvus_temp = 1299.315 - 2.415 * Co_wt - 6.362 * Cr_wt - 2.224 * Mo_wt
            solvus_temp = solvus_temp + 3.987 * W_wt + 0.958 * Re_wt + 2.424 * Ru_wt
            solvus_temp = solvus_temp - 2.603 * Al_wt - 4.943 * Ti_wt + 3.624 * Ta_wt
            if solvus_temp < 1170:
                constraint_term_5 = 0
            else:
                constraint_term_5 = 1000000000000
        return other_alloy_cost + Ni_cost + constraint_term_1 + constraint_term_2 + constraint_term_3 + constraint_term_4 + constraint_term_5

    def aimFunc(self, pop):
        Vars = pop.Phen
        # print(pop.sizes)
        obj_CL = reg.predict(np.array(Vars), return_std=True)[0]
        obj_cost = [self.cal_cost(vars) for vars in Vars]
        res = [obj_CL, obj_cost]
        res = np.mat(res)
        aim = res.T
        pop.ObjV = np.array(aim)

if __name__ == '__main__':
    # metal_content_name = ['Co', 'Mo', 'Cr', 'W', 'Al', 'Ti', 'Nb', 'Ta', 'C', 'B', 'Zr', 'Hf', 'Fe', 'V']
    # print(at2wt([0,0,0,10]))
    # exit()
    if 1:  # ML 得到CR-CP数据集合金成分
        # 把所有合金成分读进来
        # [Co, Mo, Cr, W, Al, Ti, Nb, Ta, C, B, Zr, Hf, Fe, V]
        fp = open(f"result/current-data/alloy-element.pkl", "rb")
        alloy_element = pickle.load(fp)
        fp.close()
        print("合金成分数据读取完毕！")

    # JMatpro数据集的合金成分
    if 1:
        comp = [[9.86,1.09,10.05,3.16,12.06,3.03,0.63,0,0.82,0,0,0,0,0],[10.95,4.89,21.43,0.96,3.48,4.04,0,0,0.24,0,0,0,0,0],[18.37,0,24.65,0.62,2.53,2.68,0.49,0.31,0.71,0.05,0.01,0,0,0],[10.79,6.03,21.13,0,3.43,3.87,0,0,0.43,0.03,0,0,0,0],[10.92,1.2,17.67,1.72,5.96,5.52,0.12,0,0.43,0.11,0.03,0,0,0],[0,6.25,21.93,1.47,2.78,3.13,0,0,0.35,0,0,0,0,0],[10.52,0.35,22.76,1.07,5.22,4.12,0.15,0,0.47,0.08,0.02,0,0,0],[0,1.82,36.87,1.58,2.15,1.21,0.63,0,0.39,0,0,0,0,0],[0,0,20.45,0,2.9,2.69,0,0,0.33,0,0,0,0,0],[10.05,0,10.26,3.22,12.08,1.86,0,0.82,0.74,0.08,0.03,0.5,0,0],[0,2.96,20.75,0,2.74,3.32,0,0,0.28,0,0,0,9.15,0],[0,6.04,20.12,0,7.55,2.95,0,0,0.28,0.39,0,0,0,0],[9.23,1.7,9.41,0,10.58,5,0,0,0.77,0.09,0.04,0,0,0.8],[10.69,1.13,17.39,1.65,6.37,5.5,0.12,0,0.29,0.42,0,0.1,0,0],[0,2.13,17.93,1.59,3.89,2.92,0.69,0,0.49,0,0,0,15.65,0],[0,0,22.81,0,1.88,3.19,0.85,0,0.05,0,0,0,0,0],[9.58,2.29,10.85,1.47,11.3,2.89,0,0,0.66,0.1,0.04,0,0,0],[13.84,1.7,9.41,0,10.48,5.4,0,0,0.77,0.09,0.04,0,0,0.8],[0,2.47,13.26,0,12.26,0.86,1.31,0,0.06,0.07,0.06,0,0,0],[12.01,1.23,6.8,3.21,11.91,1.54,1.84,0,0.59,0.41,0.04,0,0,0],[12.11,1.24,6.86,3.27,12.02,1.55,1.6,0,0.57,0.41,0.04,0.47,0,0],[4.77,1.76,9.73,1.07,12.51,0,1.27,0,0.47,0.1,0,0,0,0],[9.65,3.56,8.75,0,12.65,1.19,0,1.32,0.05,0.08,0.05,0,0,0],[12.58,1.72,10.04,0.42,10.79,5.16,0.44,0,0.78,0.08,0.03,0,0,0.81],[8.11,1,17.08,0.8,8.34,4.23,0.42,0.53,0.8,0.05,0,0,0,0],[9.28,0.9,17.15,1.57,6.4,4.21,1.24,0,0.48,0.08,0.03,0,0,0],[0,0,22.17,0,1.67,3.05,0,0,0.23,0,0,0,0,0],[0,1.84,16.42,1.92,4.36,2.46,0,0,0.29,0,0,0,0,0.35],[14.8,3.03,11.18,1.74,8.62,1.94,0,0,0.34,0,0,0,0,0.46],[17.06,0,20.41,0,3.1,2.92,0,0,0.47,0,0,0,0,0],[14.38,3.65,11.24,1.91,9.1,3.05,0,0,0.05,0,0,0,0,0.57],[0,2.01,16.3,1.91,5.63,2.44,0,0,0.34,0,0,0,0,0.69],[16.56,2.33,20.38,0,6.2,3.5,0,0,0.23,0,0,0,0,0],[14.32,1.76,19.47,0.46,5.21,5.88,0.01,0,0.23,0,0,0,0,0],[4.98,2.47,11.93,1.6,11.71,3.06,0,0,0.7,0.09,0.03,0,0,0],[0,3.01,16.56,0,7.41,2.9,0,0,0.69,0.39,0.04,0,0,0],[0,2.29,18.05,1.76,4.13,2.39,0,0,0.63,0.04,0,0,0,0],[0,2.59,12.72,0,12.26,0.81,1.19,0,0.23,0.05,0.06,0,0,0],[9.07,4.87,11.36,0,8.65,4.23,0,0,0.7,0,0,0,0,0],[8.18,1.03,17.44,0.8,7.35,3.85,0.49,0.55,0.71,0.05,0.06,0,0,0],[0,1.43,18.75,4.48,8.02,0,0,0,0.15,0.03,0,0,0,0],[6.46,2.57,20.85,1.98,5.87,1.47,0,0,0.24,0,0,0,0,0],[0,3.09,21.64,2.09,4.61,1.48,0,0,0.35,0,0,0,0,0],[17.04,0,21.45,0,3.1,2.91,0,0,0.46,0,0,0,0,0],[13.03,2.55,20.23,0,2.95,3.56,0,0,0.28,0,0,0,0,0]]
        alloy_element = {}
        for i in range(45):  # 45个合金
            alloy_element[i] = comp[i]

    # 生成各种成分的上限和下限
    # 合金顺序 Co Mo Cr W Al Ti Nb Ta C B Zr Hf Fe V
    # 2022.10.24 去掉 Fe:12 V:13 C:8 B:9 直接把合金成分上下限设置为0即可
    data = np.array([alloy_element[key] for key in alloy_element])
    lb = [data[:, i].min() for i in range(14)]
    ub = [data[:, i].max() for i in range(14)]
    lb[12], lb[13], lb[8], lb[9], ub[12], ub[13], ub[8], ub[9] = 0, 0, 0, 0, 0, 0, 0, 0

    # 读取高斯过程训练得到的合金-CL模型
    if 1:  # Jmatpro数据集训练得到
        fp = open(f"result/current-data-v2/Alloy-CL-model-Gaussian-process-reg.pkl", "rb")
    reg = pickle.load(fp)
    fp.close()
    print("合金-CL模型reg读取完毕！")

    problem = MyProblem(lb, ub, reg)  # 生成问题对象

    # 构建算法
    algorithm = ea.moea_NSGA2_DE_templet(problem,
                                              ea.Population(Encoding='RI', NIND=500),
                                              MAXGEN=1000,  # 最大进化代数。
                                              logTras=100)  # 表示每隔多少代记录一次日志信息，0表示不记录。
    algorithm.mutOper.Pm = 0.2  # 修改变异算子的变异概率
    algorithm.recOper.XOVR = 0.9  # 修改交叉算子的交叉概率
        # 求解

    res = ea.optimize(algorithm, drawing=1, drawLog=True)

    print(res)

    print('Happy end!')

    if 1:  # 存储结果
        fp = open(f"result/NSGA2-res.pkl", "wb")
        pickle.dump(res, fp, -1)
        fp.close()